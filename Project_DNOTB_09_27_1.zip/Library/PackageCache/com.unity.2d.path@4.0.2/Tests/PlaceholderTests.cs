using NUnit.Framework;

internal class PathPlaceholder 
{
    [Test]
    public void PlaceHolderTest()
    {
        Assert.Pass("Path tests are in a separate package.");
    }
}
