using System.Runtime.CompilerServices;
[assembly: InternalsVisibleTo("Unity.2D.Common.Tests.EditorTests")]
[assembly: InternalsVisibleTo("Unity.2D.PsdImporter.Editor")]
